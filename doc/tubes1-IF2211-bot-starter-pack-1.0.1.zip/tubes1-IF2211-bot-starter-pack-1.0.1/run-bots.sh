#!/bin/bash

python main.py --logic Greedy --email=nahli@email.com --name=nahli --password=123456 --team etimo &