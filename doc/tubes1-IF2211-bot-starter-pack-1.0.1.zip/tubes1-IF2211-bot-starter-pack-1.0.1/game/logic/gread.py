from typing import Optional
import math
from game.logic.base import BaseLogic
from game.models import GameObject, Board, Position
from ..util import get_direction


class GreedLogic(BaseLogic):
    def __init__(self):
        self.directions = [(1, 0), (0, 1), (-1, 0), (0, -1)]
        self.goal_position: Optional[Position] = None
        self.current_direction = 0

    def get_nearest_diamond(self, pos: Position, diamonds: list[Position]) -> Optional[Position]:
        """Mencari diamond terdekat dari posisi bot"""
        if not diamonds:
            return None
        
        min_dist = float('inf')
        nearest = None
        
        for diamond in diamonds:
            dist = math.sqrt((pos.x - diamond.x)**2 + (pos.y - diamond.y)**2)
            if dist < min_dist:
                min_dist = dist
                nearest = diamond
                
        return nearest

    def get_nearest_enemy(self, pos: Position, enemies: list[Position]) -> Optional[Position]:
        """Mencari musuh terdekat dari posisi bot"""
        if not enemies:
            return None
        
        min_dist = float('inf')
        nearest = None
        
        for enemy in enemies:
            dist = math.sqrt((pos.x - enemy.x)**2 + (pos.y - enemy.y)**2)
            if dist < min_dist:
                min_dist = dist
                nearest = enemy
                
        return nearest

    def get_safe_direction(self, pos: Position, enemy_pos: Position) -> tuple[int, int]:
        """Menentukan arah aman untuk menghindari musuh"""
        dx = pos.x - enemy_pos.x
        dy = pos.y - enemy_pos.y
        
        if abs(dx) > abs(dy):
            return (-1 if dx < 0 else 1, 0)
        else:
            return (0, -1 if dy < 0 else 1)

    def next_move(self, board_bot: GameObject, board: Board):
        props = board_bot.properties
        current_position = board_bot.position

        # Jika sudah 5 diamond, kembali ke base
        if props.diamonds >= 5:
            self.goal_position = props.base
        else:
            # Bot belum penuh, terapkan logika pengumpulan dan penghindaran
            # Cek musuh terdekat
            nearest_enemy = self.get_nearest_enemy(current_position, [bot.position for bot in board.bots if bot.id != board_bot.id])
            if nearest_enemy:
                enemy_dist = math.sqrt((current_position.x - nearest_enemy.x)**2 + (current_position.y - nearest_enemy.y)**2)
                # Jika musuh terlalu dekat (dalam radius 3), hindari
                if enemy_dist < 3:
                    delta_x, delta_y = self.get_safe_direction(current_position, nearest_enemy)
                    if board.is_valid_move(current_position, delta_x, delta_y):
                        return delta_x, delta_y

            # Cari diamond terdekat
            nearest_diamond = self.get_nearest_diamond(current_position, [d.position for d in board.diamonds])
            if nearest_diamond:
                self.goal_position = nearest_diamond
            else:
                # Jika tidak ada diamond, kembali ke base (ini kasus fallback jika tidak ada diamond)
                self.goal_position = props.base

        delta_x, delta_y = (0, 0) # Default ke tidak bergerak
        if self.goal_position:
            # Menghitung arah menuju goal (base atau diamond)
            delta_x, delta_y = get_direction(
                current_position.x,
                current_position.y,
                self.goal_position.x,
                self.goal_position.y,
            )

        # Periksa apakah langkah menuju goal valid, jika tidak, cari arah lain
        if not board.is_valid_move(current_position, delta_x, delta_y):
            # Coba arah lain
            for dx, dy in self.directions:
                if board.is_valid_move(current_position, dx, dy):
                    return dx, dy # Temukan arah valid pertama dan gunakan
            # Jika tidak ada arah yang valid (terjebak), tetap di tempat
            return (0, 0) 
        else:
            # Langkah menuju goal valid
            return delta_x, delta_y
